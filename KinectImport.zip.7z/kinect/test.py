# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    'name': 'Kinect',
    'author': 'Gabor Horvath',
    'version': (1, 0),
    'blender': (2, 5, 8),
    'api': 39933,
    'location': 'View3D > Properties panel > MS Kinect',
    'warning': '',
    'description': 'Import MS Kinect data, '\
        'to a rigged body.',
    'wiki_url': 'http://wiki.blender.org/index.php/Extensions:2.5/'\
        'Py/Scripts/3D_interaction/Screencast_Key_Status_Tool',
    'tracker_url': 'http://projects.blender.org/tracker/index.php?'\
        'func=detail&aid=21612',
    'category': 'Animation'}


# #####
#
# Modification history:
# - Version 1,0
# - 16-jan-2012 (GH):
# - first release contact with realtime engine
#
# ####


import bgl
import blf
import bpy
import time
import tempfile
import re
import os
import struct

arm = bpy.context.scene.objects['Armature']
bones = arm.data.bones
pose_bones = arm.pose.bones

pb = pose_bones[2] 
db = bones[2] 

pose_bones[0].location = [0,0,0.0] 
pose_bones[1].location = [0,0,1] 
pb.location = [0,0,0] 
pb.scale = [1,1,1]
pb.rotation_mode='QUATERNION'
pb.rotation_quaternion=[1,0,0,0]
pb.rotation_euler=[0,0,0]

head_pos = arm.matrix_world * db.head_local
print(head_pos)

#-------------------TEMP
                if bn.name =='spine':
                    bn.rotation_quaternion = getKQUAT(data,1); 



