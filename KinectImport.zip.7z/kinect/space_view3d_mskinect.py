# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    'name': 'Kinect',
    'author': 'Gabor Horvath',
    'version': (1, 0),
    'blender': (2, 5, 8),
    'api': 39933,
    'location': 'View3D > Properties panel > MS Kinect',
    'warning': '',
    'description': 'Import MS Kinect data, '\
        'to a rigged body.',
    'wiki_url': 'http://wiki.blender.org/index.php/Extensions:2.5/'\
        'Py/Scripts/3D_interaction/Screencast_Key_Status_Tool',
    'tracker_url': 'http://projects.blender.org/tracker/index.php?'\
        'func=detail&aid=21612',
    'category': 'Animation'}


# #####
#
# Modification history:
# - Version 1,0
# - 16-jan-2012 (GH):
# - first release contact with realtime engine
#
# ####


import bgl
import blf
import bpy
import time
import tempfile
import re
import os
import struct


recordformat = "<iQcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffcffffccc";
recordsize = 4+8+(20*(1+4+4+4+4))+3;
filekinect = 0

def getKDataIdx(jointID):
    i = 2;
    j=0;
    while 1:
        if jointID==j:
            return i;
        i = i+5;
        j=j+1

def getKData(data,jointID):
    i = getKDataIdx(jointID);
    return [data[i],data[i+1],data[i+2],data[i+3],data[i+4]];

def getKVector(data,jointID):
    i = getKDataIdx(jointID);
    return [data[i+1],data[i+2],data[i+3]];

def getKQUAT(data,jointID):
    i = getKDataIdx(jointID);
    return [data[i+4],data[i+1],data[i+2],data[i+3]];

def getkinectdataold():
    global filekinect;
    line = []
    #filekinect.seek(0,os.SEEK_END);
    #filekinect.seek(0);
    i=0;
    while 1:
        l = filekinect.readline(4);
        print(l);
        if (i>300): return False;
        #if not l: return False;
        if l == 'Data':
            break;
        i = i +1;
    
    i=0;
    while 1:        
        s =filekinect.readline();
        s = s[:-1];
        line.append(s);
        
        i = i +1;
        #if not line: break
        if i==101: break;
        if s=='Data': 
            filekinect.seek(-6,os.SEEK_CUR);            
            break;
        #print line[i];
                          
    return line;


def getkinectdataold2():
    global filekinect;
    line = []
    #filekinect.seek(1000,os.SEEK_END);
    #os.lseek(filekinect,-1000,os.SEEK_END);
    #filekinect.readline();
    
    s = filekinect.readline();
    while 1:
        s2 = filekinect.readline();
        if (s2 == ""): break;
        s = s2;
    
    if s[:4]=="Data":
        s=s[:-1];
        line = re.findall(r'[a-zA-Z0-9_,.-]+', s);
    
    return line;


def getkinectdata():
    global filekinect;
    line = []
    #filekinect.seek(-(2*recordsize)+1,2);
    temp_data=filekinect.read((2*recordsize)-1);
    
    i=0;
    #print(len(temp_data));
    while i<recordsize:
        c2 = str(temp_data[i:i+4], "utf-8", "replace");
        if c2=="DATA":
            line = temp_data[i:i+recordsize];
            #print("DATA",i,len(line));            
            break;
        i = i +1;
    
    return line;
        

def draw_callback_px(self, context):
    wm = context.window_manager
    sc = context.scene
    if not wm.screencast_keys_keys:
        return
    
    scene = context.scene;
    
    print(context.scene.frame_current);   
    print("-----------");
    
    data2 = getkinectdata();
    data = struct.unpack(recordformat, data2);
   
    j=0;
    objects = (ob for ob in scene.objects if ob.is_visible(scene) and ob.name=='Armature')
    
    for ob in objects:            
        if ((ob.type=='ARMATURE') and (ob.pose != None)):
            for bn in ob.pose.bones:
                if bn.name =='hips':
                    bn.location=getKVector(data,0);
                    print(bn.location);
                if bn.name =='spine':
                    bn.rotation_mode='QUATERNION'
                    bn.rotation_quaternion=getKQUAT(data,1);      
                    print(bn.rotation_quaternion);


class ScreencastKeysStatus(bpy.types.Operator):
    bl_idname = "animation.mskinect"
    bl_label = "MS Kinect Import"
    bl_description = "Import kinect data"
    last_activity = 'NONE'

    def modal(self, context, event):
        return {'PASS_THROUGH'}


    def cancel(self, context):
        if context.window_manager.screencast_keys_keys:
            context.region.callback_remove(self._handle)
            context.window_manager.screencast_keys_keys = False
        return {'CANCELLED'}


    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            global filekinect;
            if context.window_manager.screencast_keys_keys == False:
                # operator is called for the first time, start everything
                print("INVOKE1");
                context.window_manager.screencast_keys_keys = True
                context.window_manager.modal_handler_add(self)
                self.key = []
                self.time = []
                self.mouse = []
                self.mouse_time = []
                self._handle = context.region.callback_add(draw_callback_px,
                    (self, context), 'POST_PIXEL')
                
                context.scene.use_audio_sync = True;
                context.tool_settings.auto_keying_mode = 'ADD_REPLACE_KEYS';
                context.tool_settings.use_keyframe_insert_auto = True;
                bpy.ops.screen.animation_play();
                
                temppath = tempfile.gettempdir();
                print(temppath);
                filekinect = open(temppath + "\\kinectdata.hgbk" , 'rb');                
                #fileini.write("GL3DC initial informations\nHGPLSoft\n\n")
                return {'RUNNING_MODAL'}                
            else:
                # operator is called again, stop displaying
                context.window_manager.screencast_keys_keys = False
                self.key = []
                self.time = []
                self.mouse = []
                self.mouse_time = []
                
                bpy.ops.screen.animation_play();
                filekinect.close();
                return {'CANCELLED'}
        else:
            self.report({'WARNING'}, "View3D not found, can't run operator")
            return {'CANCELLED'}
        
    def execute(self, context):
        print("foobar")
        return {'FINISHED'}


# properties used by the script
def init_properties():

    sc = bpy.types.Scene
    wm = bpy.types.WindowManager

    sc.screencast_keys_pos_x = bpy.props.IntProperty(
            name="Pos X",
            description="Margin on the x axis",
            default=5,
            min=0,
            max=100)

    sc.screencast_keys_pos_y = bpy.props.IntProperty(
            name="Pos Y",
            description="Margin on the y axis",
            default=10,
            min=0,
            max=100)

    sc.screencast_keys_font_size = bpy.props.IntProperty(
            name="Font",
            description="Fontsize",
            default=20, min=10, max=150)

    sc.screencast_keys_mouse_size = bpy.props.IntProperty(
            name="Mouse",
            description="Mousesize",
            default=60, min=10, max=150)


    sc.screencast_keys_color = bpy.props.FloatVectorProperty(
            name="Color",
            description="Font color",
            default=(1.0, 1.0, 1.0),
            min=0,
            max=1,
            subtype='COLOR')

    sc.screencast_keys_mouse = bpy.props.EnumProperty(
            items=(("none", "None", "Don't display mouse events"), 
                  ("icon", "Icon", "Display graphical represenation of "\
                   "the mouse"),
                  ("text", "Text", "Display mouse events as text lines")),
            name="Mouse display",
            description="Display mouse events",
            default='text')

    sc.screencast_keys_link = bpy.props.BoolProperty(
            name="From start",
            description = "From first stored data ",
            default = False)

    print ("Kinect: initialized from AddOn default settings.")

    # Runstate initially always set to False
    # note: it is not stored in the Scene, but in window manager:
    wm.screencast_keys_keys      = bpy.props.BoolProperty(default=False)


# removal of properties when script is disabled
def clear_properties():
    props = ["screencast_keys_keys", "screencast_keys_mouse",
     "screencast_keys_font_size", "screencast_keys_mouse_size",
     "screencast_keys_pos_x", "screencast_keys_pos_y", "screencast_keys_link"]
    for p in props:
        if bpy.context.window_manager.get(p) != None:
            del bpy.context.window_manager[p]
        try:
            x = getattr(bpy.types.WindowManager, p)
            del x
        except:
            pass


# defining the panel
class OBJECT_PT_keys_status(bpy.types.Panel):
    bl_label = "MS Kinect"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    
    def draw(self, context):
        sc = context.scene
        wm = context.window_manager
        layout = self.layout
        
        if not wm.screencast_keys_keys:
            layout.operator("animation.mskinect", text="Start import",
                icon='PLAY')
        else:
            layout.operator("animation.mskinect", text="Stop import",
                icon='PAUSE')
        
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(sc, "screencast_keys_pos_x")
        row.prop(sc, "screencast_keys_pos_y")
        row = col.row(align=True)
        row.prop(sc, "screencast_keys_font_size")
        row.prop(sc, "screencast_keys_mouse_size")
        row = col.row(align=True)
        row.prop(sc, "screencast_keys_mouse", text="Mouse")
        row = col.row(align=True)
        row.prop(sc, "screencast_keys_link")
        
        layout.prop(sc, "screencast_keys_color")


classes = [ScreencastKeysStatus,
    OBJECT_PT_keys_status]


def register():
    init_properties()
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)
    clear_properties()


if __name__ == "__main__":
    register()

